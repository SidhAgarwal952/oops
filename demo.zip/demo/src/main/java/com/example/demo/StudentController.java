package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentService studentService;

    // REST API Endpoints for Postman testing

    // 1. Create Student (REST API - for Postman)
    @PostMapping
    @ResponseBody
    public Student createStudentApi(@RequestBody Student student) {
        return studentService.createStudent(student);
    }

    // 2. Get All Students (REST API - for Postman)
    @GetMapping
    @ResponseBody
    public List<Student> getAllStudentsApi() {
        return studentService.getAllStudents();
    }

    // 3. Get Student by ID (REST API - for Postman)
    @GetMapping("/{id}")
    @ResponseBody
    public Student getStudentByIdApi(@PathVariable Long id) {
        return studentService.getStudentById(id);
    }

    // 4. Update Student (REST API - for Postman)
    @PutMapping("/{id}")
    @ResponseBody
    public Student updateStudentApi(@PathVariable Long id, @RequestBody Student student) {
        return studentService.updateStudent(id, student);
    }

    // 5. Delete Student (REST API - for Postman)
    @DeleteMapping("/{id}")
    @ResponseBody
    public String deleteStudentApi(@PathVariable Long id) {
        boolean deleted = studentService.deleteStudent(id);
        return deleted ? "Student deleted successfully" : "Student not found";
    }

    // UI Endpoints for Web Interface

    // 1. Show all students (UI)
    @GetMapping("/ui")
    public String getAllStudents(Model model) {
        List<Student> students = studentService.getAllStudents();
        model.addAttribute("students", students);
        return "students"; // This will look for students.html
    }

    // 2. Show add student form (UI)
    @GetMapping("/ui/add")
    public String showAddForm(Model model) {
        model.addAttribute("student", new Student());
        model.addAttribute("isUpdate", false);
        return "student-form"; // This will look for student-form.html
    }

    // 3. Save student (UI - for both add and update)
    @PostMapping("/ui/save")
    public String saveStudent(@ModelAttribute Student student) {
        if (student.getId() == null) {
            // New student
            studentService.createStudent(student);
        } else {
            // Update existing student
            studentService.updateStudent(student.getId(), student);
        }
        return "redirect:/students/ui";
    }

    // 4. Show edit form (UI)
    @GetMapping("/ui/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Student student = studentService.getStudentById(id);
        if (student != null) {
            model.addAttribute("student", student);
            model.addAttribute("isUpdate", true);
            return "student-form";
        }
        return "redirect:/students/ui";
    }

    // 5. Delete student (UI)
    @GetMapping("/ui/delete/{id}")
    public String deleteStudent(@PathVariable Long id) {
        studentService.deleteStudent(id);
        return "redirect:/students/ui";
    }
}